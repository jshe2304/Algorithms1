public class HelloGoodbye {
    public static void main (String[] args) {
        //System.out.println("Test\n");
        if (args.length == 2) {
            System.out.println("Hello " + args[0] + " and " + args[1] + ".");
            System.out.println("Goodbye " + args[1] + " and " + args[0] + ".");
        } else {
            System.out.println("Must include 2 names as arguments");
        }
    }
}
