
//package week3.mergesort;
//import week3.LineSegment;

import edu.princeton.cs.algs4.StdOut;


import edu.princeton.cs.algs4.LinkedQueue;
public class BruteCollinearPoints {

    private final LinkedQueue<LineSegment> segments;

    public BruteCollinearPoints(Point[] points) {
        segments = new LinkedQueue<LineSegment>();

        for (int i = 0; i < points.length; i++) {
            for (int j = i+1; j < points.length; j++) {
                for (int k = j+1; k < points.length; k++) {
                    for (int l = k+1; l < points.length; l++) {
                        if (points[i].slopeTo(points[j]) == points[j].slopeTo(points[k]) && points[j].slopeTo(points[k]) == points[k].slopeTo(points[l])) {
                            segments.enqueue(new LineSegment(points[i], points[l]));
                        }
                    }
                }
            }
        }
    }

    public int numberOfSegments() {
        return segments.size();
    }

    public LineSegment[] segments() {
        //System.out.println(numberOfSegments());

        LineSegment[] arr = new LineSegment[numberOfSegments()];

        int i = 0;

        for (LineSegment line : segments) {
            arr[i] = line;
            i++;
        }

        /*
        int size = segments.size();

        for (int i = 0; i < size; i++) {
            arr[i] = segments.dequeue();
        }

         */

        return arr;
    }

    public static void main (String[] args) {
        /*
        Point[] points = new Point[16];

        int index = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                points[index] = new Point(i, j);
                index++;
            }
        }


        for (int i = 0; i < 16; i++) {
            System.out.println(points[i]);
        }



        BruteCollinearPoints brute = new BruteCollinearPoints(points);

        System.out.println(brute.numberOfSegments());

        //System.out.println(ls.length);
        for (LineSegment segment : brute.segments()) {
            StdOut.println(segment);
        }
        */
    }
}
